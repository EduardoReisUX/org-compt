

#include <stdio.h>
 
int main()
{
  int a;
 
  printf("Enter an integer\n");
  scanf("%d", &a);
 
  printf("Integer that you have entered is %d\n", a);
 
  return 0;
}