#include <stdio.h>
main()
{
    printf("Hello Word \n");

}
