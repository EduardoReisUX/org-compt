#include <stdio.h>

int strlen2 (char *str)
{
    char ch;
    char *strptr;
    int len = 0;
    
    strptr = str;
    
    while(*strptr != '\0'){
        len++;
        strptr++;
    }
    return len;
}


int main (void)
{
    char string[32];
    int tam;
    
    printf ("Entre com a string: \n");
    scanf("%s", string);
    tam = strlen2(string);
    printf("O tamanho da string: %d\n", tam);
}