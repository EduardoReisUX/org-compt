#include <stdio.h>

float f1;
float f2;
float f3;
main()
{
 printf("entre com um float:");
 scanf ("%f",&f1);
 printf("entre com um float:");
 scanf ("%f",&f2);
 f3= f1+f2;
 printf("a soma eh: %f\n", f3);
 return 0;
    
}