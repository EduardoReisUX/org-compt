#include <stdio.h>

int a;
int b;

int main (void)
{
   printf("Entre com a:");
   scanf ("%d", &a);
   printf("Entre com b:");
   scanf ("%d", &b);
   if (a > b) {
       printf("a é maior\n");
   }
   else {
      if (a == b) {
           printf("são iguais\n");
      }
      else {
           printf("b é maior\n");
      }
   }
   return 0;
}